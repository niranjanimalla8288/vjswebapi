<template>
<div class="container">
<h4>Products List</h4>
      <table class="table table-bordered">
        <tr
          :class="{ active: index == currentIndex }"
          v-for="(product, index) in products"
          :key="index"
          @click="setActiveproduct(product, index)">

          <td>{{ product.ProductID }}</td>
          <td>{{ product.ProductName }}</td>
          <td>{{ product.SupplierID }}</td>
          <td>{{ product.CategoryID }}</td>
          <td>{{ product.QuantityPerUnit }}</td>
          <td>{{ product.UnitPrice }}</td>
          <td>{{ product.UnitsInStock }}</td>
          <td>{{ product.UnitsOnOrder }}</td>
          <td>{{ product.ReorderLevel }}</td>
          <td>{{ product.Discontinued }}</td>   
          <td><router-link :to="'/products/' + product.ProductID" class="badge badge-warning">Edit</router-link></td>       	
        </tr>
      </table>
</div>
</template>

<script>


import ProductDataService from "../services/ProductDataService";
export default {
  name: "products-list",
  data() {
    return {
      products: [],
      currentproduct: null,
      currentIndex: -1,
      title: ""
    };
  },
  methods: {
    retrieveproducts() {
      ProductDataService.getAll()
        .then(response => {
          this.products = response.data;
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
    },

    refreshList() {
      this.retrieveproducts();
      this.currentproduct = null;
      this.currentIndex = -1;
    },

    setActiveproduct(product, index) {
      this.currentproduct = product;
      this.currentIndex = index;
    },

    removeAllproducts() {
      ProductDataService.deleteAll()
        .then(response => {
          console.log(response.data);
          this.refreshList();
        })
        .catch(e => {
          console.log(e);
        });
    },
    
    searchTitle() {
      ProductDataService.findByTitle(this.title)
        .then(response => {
          this.products = response.data;
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
    }
  },
  mounted() {
    this.retrieveproducts();
  }
};
</script>


