<template>
  <div class="submit-form">
    <div v-if="!submitted">
      <div class="form-group">
        <label for="ProductName">Product Name</label>
        <input
          type="text"
          class="form-control"
          id="ProductName"
          required
          v-model="product.ProductName"
          name="ProductName"
        />
      </div>
       <div class="form-group">
        <label for="title">Supplier</label>
        <select  class="form-control"  v-model="product.SupplierID" required id="SupplierID" name="SupplierID">
        <option value="-1" selected>Select Supplier </option>
        <option v-bind:value=supplier.SupplierID v-for="(supplier, index) in suppliers"
          :key="index">{{supplier.CompanyName}}</option>
        </select>
      </div>
        <div class="form-group">
        <label for="title">Category</label>
        <select  class="form-control" v-model="product.CategoryID"  id="CategoryID" name="CategoryID">
       <option value="-1" selected>Select Category </option>
        <option v-bind:value=category.CategoryID v-for="(category, index) in categories"
          :key="index">{{category.CategoryName}}</option>
        </select>
      </div>
       <div class="form-group">
        <label for="QuantityPerUnit">QuantityPerUnit</label>
        <input
          type="text"
          class="form-control"
          id="QuantityPerUnit"
          required
          v-model="product.QuantityPerUnit"
          name="QuantityPerUnit"
        />
      </div>
       <div class="form-group">
        <label for="UnitPrice">UnitPrice</label>
        <input
          type="text"
          class="form-control"
          id="UnitPrice"
          required
          v-model="product.UnitPrice"
          name="UnitPrice"
        />
      </div>
       <div class="form-group">
        <label for="UnitsInStock">UnitsInStock</label>
        <input
          type="text"
          class="form-control"
          id="UnitsInStock"
          required
          v-model="product.UnitsInStock"
          name="UnitsInStock"
        />
      </div>
       <div class="form-group">
        <label for="ReorderLevel">ReorderLevel</label>
        <input
          type="text"
          class="form-control"
          id="ReorderLevel"
          required
          v-model="product.ReorderLevel"
          name="ReorderLevel"
        />
      </div>
       <div class="form-group">
        <label for="UnitPrice">Discontinued</label>
       <div class="form-check">
  <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
  <label class="form-check-label" for="flexCheckDefault">
    Default checkbox
  </label>
</div>
      </div>

     
      <button @click="saveProduct" class="btn btn-success">Submit</button>
      <button @click="deleteProduct" class="btn btn-danger">Delete</button>
    </div>

    <div v-else>
      <h4>You submitted successfully!</h4>
    </div>
  </div>
</template>

<script>
import ProductDataService from "../services/ProductDataService";

export default {
  name: "add-product",
  data() {
      return {
        suppliers:[],
        categories:[] ,
      product: {
        ProductID:0,
        ProductName:"",
        SupplierID:0,
        CategoryID:0,
        QuantityPerUnit:0,
        UnitPrice:0,
        UnitsInStock:0,
        UnitsOnOrder:	0,
        ReorderLevel:	0,
        Discontinued:false
      },
      submitted: false
    };
  },
  methods: {

     getSuppliers() {
      ProductDataService.getSuppliers()
        .then(response => {
          this.suppliers = response.data;
          console.log(response.data);
        })
        .catch(e => { 
          console.log(e);
        });
        },

       getCategories() {
        ProductDataService.getCategories()
        .then(response => {
          this.categories = response.data;
          console.log(response.data);
        })
        .catch(e => {
          console.log(e);
        });
      },

      getProduct(id) {
        ProductDataService.get(id)
        .then(response => {
          this.product = response.data;          
        })
        .catch(e => {
          console.log(e);
        });
      },
    saveProduct() {
      var data = {  
        ProductID:this.product.ProductID,      
        ProductName:this.product.ProductName,
        SupplierID:this.product.SupplierID,
        CategoryID:this.product.CategoryID,
        QuantityPerUnit:this.product.QuantityPerUnit,
        UnitPrice:this.product.UnitPrice,
        UnitsInStock:this.product.UnitsInStock,
        UnitsOnOrder:	this.product.UnitsOnOrder,
        ReorderLevel:	this.product.ReorderLevel,
        Discontinued:this.product.Discontinued
      };

      ProductDataService.update(this.product.ProductID,data)
        .then(response => {
          this.product.ProductID = response.data.id;
          console.log(response.data);
          this.submitted = true;
        })
        .catch(e => {
          console.log(e);
        });
    },

    deleteProduct() {
      ProductDataService.delete(this.product.ProductID)
        .then(response => {
          console.log(response.data);
          this.$router.push({ name: "products" });
        })
        .catch(e => {
          console.log(e);
        });
      }
    },

  mounted() {
    this.getSuppliers();
    this.getCategories();
    this.getProduct(this.$route.params.id);
  }
};
</script>

<style>
.submit-form {
  max-width: 300px;
  margin: auto;
}
</style>
